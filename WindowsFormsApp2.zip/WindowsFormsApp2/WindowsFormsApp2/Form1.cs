﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection conection;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        string query;
        DataTable match = new DataTable();
        DataTable dt = new DataTable();
        DataTable detail = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            
            conection = new MySqlConnection("server = localhost; uid = root; pwd = isbmantap; database = premier_league");
            conection.Open();
            conection.Close();
            query = "select team_name,team_id from team";
            command = new MySqlCommand(query, conection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt);
            cb_team.DataSource = dt;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name";

            detail.Columns.Add("Minute");
            detail.Columns.Add("Team Id");
            detail.Columns.Add("Player Id");
            detail.Columns.Add("Type");
            dgv_mboh.DataSource = detail;

            
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable player = new DataTable();
            string query = $"Select player_name,player_id from player where player.team_id = '{cb_team.SelectedValue}'";
            command = new MySqlCommand(query, conection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.ValueMember = "player_id";
            cb_player.DisplayMember = "player_name";



        }

        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string kquery = $"select * from dmatch where player_id = '{cb_player.SelectedValue}'";
            command = new MySqlCommand(kquery, conection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(match);
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

            if (cb_team.SelectedValue != null && cb_player.SelectedValue != null && cb_type.Text != null && txt_minute.Text != null)
            {
                if (cb_type.Text == "Goal")
                {
                    cb_type.Text = "GO";
                }
                if (cb_type.Text == "Goal Penalty")
                {
                    cb_type.Text = "GP";
                }
                if (cb_type.Text == "Red Card")
                {
                    cb_type.Text = "CR";
                }
                if (cb_type.Text == "Yellow Card")
                {
                    cb_type.Text = "YR";
                }
                if (cb_type.Text == "Red Card")
                {
                    cb_type.Text = "CR";
                }
                if (cb_type.Text == "Penalty Miss")
                {
                    cb_type.Text = "PM";
                }
                if (cb_type.Text == "Own Goal")
                {
                    cb_type.Text = "OG";
                }

                detail.Rows.Add(txt_minute.Text,cb_team.SelectedValue,cb_player.SelectedValue,cb_type.Text);
                cb_team.Text = null;
                cb_player.Text = null;
                cb_type.Text = null;
                txt_minute.Text = null;
            }
        }

        private void cek()
        {
           
        }
    }
}
