﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_tim = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.dgv_mboh = new System.Windows.Forms.DataGridView();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.lbl_player = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.lbl_type = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_minute = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mboh)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_tim
            // 
            this.lbl_tim.AutoSize = true;
            this.lbl_tim.Location = new System.Drawing.Point(38, 49);
            this.lbl_tim.Name = "lbl_tim";
            this.lbl_tim.Size = new System.Drawing.Size(66, 25);
            this.lbl_tim.TabIndex = 0;
            this.lbl_tim.Text = "Team";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(151, 49);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(272, 33);
            this.cb_team.TabIndex = 1;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // dgv_mboh
            // 
            this.dgv_mboh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_mboh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mboh.Location = new System.Drawing.Point(43, 141);
            this.dgv_mboh.Name = "dgv_mboh";
            this.dgv_mboh.RowHeadersWidth = 82;
            this.dgv_mboh.RowTemplate.Height = 33;
            this.dgv_mboh.Size = new System.Drawing.Size(2115, 1127);
            this.dgv_mboh.TabIndex = 2;
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(621, 49);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(272, 33);
            this.cb_player.TabIndex = 4;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(508, 49);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(71, 25);
            this.lbl_player.TabIndex = 3;
            this.lbl_player.Text = "player";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1479, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "minute";
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "Goal ",
            "Goal Penalty",
            "Red Card",
            "Yellow Card",
            "Penalty Miss",
            "Own Goal"});
            this.cb_type.Location = new System.Drawing.Point(1141, 57);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(272, 33);
            this.cb_type.TabIndex = 8;
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(1031, 52);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(53, 25);
            this.lbl_type.TabIndex = 7;
            this.lbl_type.Text = "type";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1911, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 30);
            this.button1.TabIndex = 9;
            this.button1.Text = "add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_minute
            // 
            this.txt_minute.Location = new System.Drawing.Point(1601, 52);
            this.txt_minute.Name = "txt_minute";
            this.txt_minute.Size = new System.Drawing.Size(216, 31);
            this.txt_minute.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2276, 1364);
            this.Controls.Add(this.txt_minute);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.dgv_mboh);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.lbl_tim);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mboh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_tim;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.DataGridView dgv_mboh;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_minute;
    }
}

